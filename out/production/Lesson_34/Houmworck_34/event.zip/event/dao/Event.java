
package Houmworck_34.event.dao;

import java.time.LocalDate;
import java.util.List;

public interface Event {

    boolean addEvent(Event event);
    boolean removeEvent(int id);
    boolean updateEvent(int id, String url);
    Event getEventById(int id);
    List<Event> getEventsBetweenDates(LocalDate dateFrom, LocalDate dateTo);
    int size();
}
