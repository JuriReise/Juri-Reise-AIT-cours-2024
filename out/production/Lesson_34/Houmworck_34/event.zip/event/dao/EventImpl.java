
package Houmworck_34.event.dao;

import Houmworck_34.event.model.Event;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EventImpl implements Event {
    private List<Event> events;

    public EventImpl() {
        this.events = new ArrayList<>();
    }

    @Override
    public boolean addEvent(Event event) {
        return events.add(event);
    }

    @Override
    public boolean removeEvent(int id) {
        return events.removeIf(event -> event.getId() == id);
    }

    @Override
    public boolean updateEvent(int id, String url) {
        Event event = getEventById(id);
        if (event != null) {
            event.setUrl(url);
            return true;
        }
        return false;
    }

    @Override
    public Event getEventById(int id) {
        return events.stream().filter(event -> event.getId() == id).findFirst().orElse(null);
    }

    @Override
    public List<Event> getEventsBetweenDates(LocalDate dateFrom, LocalDate dateTo) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            LocalDate eventDate = event.getDate().toLocalDate();
            if ((eventDate.isEqual(dateFrom) || eventDate.isAfter(dateFrom)) &&
                (eventDate.isEqual(dateTo) || eventDate.isBefore(dateTo))) {
                result.add(event);
            }
        }
        return result;
    }

    @Override
    public int size() {
        return events.size();
    }
}
